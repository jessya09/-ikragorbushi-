<?php
function writeAuditLog($action, $description, $user_id = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (action, description, user_id, ip_address, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $action,
            $description,
            $user_id,
            $_SERVER['REMOTE_ADDR']
        ]);
    } catch (PDOException $e) {
        // Записываем ошибку в системный лог, так как это критически важная функциональность
        error_log("Ошибка записи в audit_log: " . $e->getMessage());
    }
}