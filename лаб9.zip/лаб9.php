<?php
session_start();
require_once('../config/database.php');
require_once('../includes/audit_log.php'); // Добавим файл для логирования

// Усиленная проверка прав администратора
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // Логируем попытку несанкционированного доступа
    writeAuditLog('unauthorized_access', 'Попытка удаления комнаты без прав администратора', 
        isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null);
    header('Location: ../login.php?error=' . urlencode('Доступ запрещен'));
    exit();
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $room_id = (int)$_GET['id'];
    
    try {
        $pdo->beginTransaction();
        
        // Проверяем существование комнаты
        $stmt = $pdo->prepare("SELECT id FROM rooms WHERE id = ?");
        $stmt->execute([$room_id]);
        if (!$stmt->fetch()) {
            throw new Exception('Комната не найдена');
        }

        // Проверяем наличие активных бронирований для номера
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE room_id = ? AND status != 'cancelled'");
        $stmt->execute([$room_id]);
        $hasBookings = $stmt->fetchColumn() > 0;
        
        if (!$hasBookings) {
            // Если нет активных бронирований, удаляем номер
            $stmt = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
            $stmt->execute([$room_id]);
            
            // Логируем успешное удаление
            writeAuditLog('room_deleted', "Удалена комната ID: $room_id", $_SESSION['user_id']);
            
            $pdo->commit();
            header('Location: dashboard.php?success=' . urlencode('Комната успешно удалена'));
            exit();
        } else {
            throw new Exception('Невозможно удалить номер с активными бронированиями');
        }
    } catch(Exception $e) {
        $pdo->rollBack();
        writeAuditLog('room_delete_error', $e->getMessage(), $_SESSION['user_id']);
        header('Location: dashboard.php?error=' . urlencode($e->getMessage()));
        exit();
    }
} else {
    writeAuditLog('room_delete_error', 'Некорректный ID комнаты', $_SESSION['user_id']);
    header('Location: dashboard.php?error=' . urlencode('Некорректный ID комнаты'));
    exit();
}
?>