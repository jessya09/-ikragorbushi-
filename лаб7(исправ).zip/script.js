let currentInput = '0';
let previousInput = '';
let currentOperation = null;
let shouldResetDisplay = false;

const display = document.getElementById('display');

function updateDisplay() {
    display.value = currentInput;
}

function addNumber(num) {
    if (shouldResetDisplay) {
        currentInput = num;
        shouldResetDisplay = false;
    } else {
        currentInput = currentInput === '0' ? num : currentInput + num;
    }
    updateDisplay();
}

function addDecimal() {
    if (!currentInput.includes('.')) {
        currentInput += '.';
        updateDisplay();
    }
}

function clearEntry() {
    currentInput = '0';
    updateDisplay();
}

function clearAll() {
    currentInput = '0';
    previousInput = '';
    currentOperation = null;
    updateDisplay();
}

function backspace() {
    currentInput = currentInput.slice(0, -1) || '0';
    updateDisplay();
}

function performOperation(op) {
    if (currentOperation !== null) calculate();
    previousInput = currentInput;
    currentOperation = op;
    shouldResetDisplay = true;
}

function calculate() {
    if (!currentOperation || !previousInput) return;
    
    let result;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);

    try {
        switch(currentOperation) {
            case '+': result = prev + current; break;
            case '-': result = prev - current; break;
            case '*': result = prev * current; break;
            case '/': 
                if (current === 0) throw new Error('Деление на ноль невозможно');
                result = prev / current; 
                break;
        }

        currentInput = result.toString();
        currentOperation = null;
        previousInput = '';
        updateDisplay();
    } catch(e) {
        alert(e.message);
        clearAll();
    }
}

function toggleSign() {
    currentInput = (parseFloat(currentInput) * -1).toString();
    updateDisplay();
}

function reciprocal() {
    try {
        if (parseFloat(currentInput) === 0) throw new Error('Деление на ноль невозможно');
        currentInput = (1 / parseFloat(currentInput)).toString();
        updateDisplay();
    } catch(e) {
        alert(e.message);
        clearAll();
    }
}

function sqrt() {
    try {
        const num = parseFloat(currentInput);
        if (num < 0) throw new Error('Невозможно извлечь корень из отрицательного числа');
        currentInput = Math.sqrt(num).toString();
        updateDisplay();
    } catch(e) {
        alert(e.message);
        clearAll();
    }
}

function percent() {
    if (previousInput && currentOperation) {
        currentInput = (parseFloat(previousInput) * parseFloat(currentInput) / 100).toString();
        updateDisplay();
    }
}

// Инициализация дисплея
updateDisplay();

// Добавление обработчика клавиатуры
document.addEventListener('keydown', (event) => {
    if (/[0-9]/.test(event.key)) {
        addNumber(event.key);
    } else if (event.key === '.') {
        addDecimal();
    } else if (event.key === 'Backspace') {
        backspace();
    } else if (event.key === 'Escape') {
        clearAll();
    } else if (event.key === 'Enter') {
        calculate();
    } else if (['+', '-', '*', '/'].includes(event.key)) {
        performOperation(event.key);
    }
});