const monthSelect = document.getElementById('monthSelect');
const yearSelect = document.getElementById('yearSelect');
const generateCalendarButton = document.getElementById('generateCalendar');
const calendarBody = document.getElementById('calendarBody');

// Заполнение выпадающих списков месяцев и лет
function populateSelects() {
    const months = [
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
    ];
    months.forEach((month, index) => {
        const option = document.createElement('option');
        option.value = index;
        option.textContent = month;
        monthSelect.appendChild(option);
    });

    const currentYear = new Date().getFullYear();
    for (let year = currentYear - 10; year <= currentYear + 10; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }

    // Установка текущего месяца и года по умолчанию
    monthSelect.value = new Date().getMonth();
    yearSelect.value = currentYear;
}

// Генерация календаря
function generateCalendar(year = new Date().getFullYear(), month = new Date().getMonth()) {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startDay = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1; // Понедельник как первый день

    let calendarHTML = '';
    let dayCounter = 1;

    for (let i = 0; i < 6; i++) {
        calendarHTML += '<tr>';
        for (let j = 0; j < 7; j++) {
            if (i === 0 && j < startDay) {
                calendarHTML += '<td></td>';
            } else if (dayCounter > daysInMonth) {
                calendarHTML += '<td></td>';
            } else {
                const dayClass = j >= 5 ? 'weekend' : ''; // Выходные дни
                const isHoliday = isHolidayDay(year, month, dayCounter);
                if (isHoliday) {
                    calendarHTML += `<td class="${dayClass} holiday">${dayCounter}</td>`;
                } else {
                    calendarHTML += `<td class="${dayClass}">${dayCounter}</td>`;
                }
                dayCounter++;
            }
        }
        calendarHTML += '</tr>';
    }

    calendarBody.innerHTML = calendarHTML;
}

// Проверка на праздничные дни
function isHolidayDay(year, month, day) {
    const holidays = [
        new Date(year, 0, 1), // Новый год
        new Date(year, 2, 8), // Международный женский день
        new Date(year, 4, 1), // День труда
        new Date(year, 4, 9), // День Победы
        new Date(year, 11, 12), // День Конституции Украины
    ];

    const date = new Date(year, month, day);
    return holidays.some(holiday => holiday.toDateString() === date.toDateString());
}

// Обработчик кнопки "Показать календарь"
generateCalendarButton.addEventListener('click', () => {
    const selectedYear = parseInt(yearSelect.value);
    const selectedMonth = parseInt(monthSelect.value);
    generateCalendar(selectedYear, selectedMonth);
});

// Инициализация
populateSelects();
generateCalendar(); // По умолчанию отображает текущий месяц