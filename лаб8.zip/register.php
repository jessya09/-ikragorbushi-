<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $fio = htmlspecialchars($_POST['fio']);
    $login = htmlspecialchars($_POST['login']);
    $password = htmlspecialchars($_POST['password']);
    $birthdate = htmlspecialchars($_POST['birthdate']);


    if (empty($fio) || empty($login) || empty($password) || empty($birthdate)) {
        echo "Пожалуйста, заполните все поля.";
        exit;
    }


    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Подключение к базе данных
    $host = 'localhost'; 
    $db_name = 'your_database_name'; 
    $username = 'your_username'; 
    $password_db = 'your_password'; 

    try {
        $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password_db);
       
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Подготовка SQL-запроса для вставки данных
        $stmt = $conn->prepare("INSERT INTO users (fio, login, password, birthdate) VALUES (:fio, :login, :password, :birthdate)");

     
        $stmt->bindParam(':fio', $fio);
        $stmt->bindParam(':login', $login);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':birthdate', $birthdate);

     
        $stmt->execute();

        echo "Регистрация прошла успешно!";
    } catch (PDOException $e) {
        // Обработка ошибок подключения или запроса
        echo "Ошибка: " . $e->getMessage();
    }

  
    $conn = null;
} else {
    echo "Ошибка: Форма не была отправлена.";
}
?>