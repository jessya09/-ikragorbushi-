<?php
require_once 'config.php';

if (!isAdmin()) {
    header("Location: login.php");
    exit;
}

// Удаление пользователя
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ? AND role_id != 1");
    $stmt->execute([$_GET['delete']]);
    header("Location: users.php");
    exit;
}

// Получение списка пользователей
$stmt = $pdo->query("SELECT users.*, roles.role_name 
                     FROM users 
                     JOIN roles ON users.role_id = roles.role_id");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Управление пользователями</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Управление пользователями</h2>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Логин</th>
            <th>ФИО</th>
            <th>Email</th>
            <th>Телефон</th>
            <th>Роль</th>
            <th>Действия</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo $user['user_id']; ?></td>
            <td><?php echo htmlspecialchars($user['login']); ?></td>
            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td><?php echo htmlspecialchars($user['phone']); ?></td>
            <td><?php echo htmlspecialchars($user['role_name']); ?></td>
            <td>
                <a href="edit_user.php?id=<?php echo $user['user_id']; ?>">Редактировать</a>
                <?php if ($user['role_id'] != 1): ?>
                    | <a href="users.php?delete=<?php echo $user['user_id']; ?>" 
                         onclick="return confirm('Вы уверены?')">Удалить</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html> 