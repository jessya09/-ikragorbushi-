<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user) {
        // Добавляем отладочную информацию
        echo "Введенный пароль: " . $password . "<br>";
        echo "Хеш в базе: " . $user['password'] . "<br>";
        echo "Результат проверки: " . (password_verify($password, $user['password']) ? 'true' : 'false') . "<br>";
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_role'] = $user['role_id'];
            $_SESSION['user_name'] = $user['full_name'];
            
            header("Location: profile.php");
            exit;
        }
    }
    $error = "Неверный логин или пароль";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Вход</title>
    <style>
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Вход в систему</h2>
    
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div>
            <label>Логин:</label>
            <input type="text" name="login">
        </div>

        <div>
            <label>Пароль:</label>
            <input type="password" name="password">
        </div>

        <button type="submit">Войти</button>
    </form>
    
    <p>Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>
</body>
</html> 