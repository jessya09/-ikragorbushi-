<?php
require_once 'config.php';

if (!isAuthenticated()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    if (!empty($_POST['new_password'])) {
        $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, password = ? WHERE user_id = ?";
        $params = [$full_name, $email, $phone, $password, $user_id];
    } else {
        $sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?";
        $params = [$full_name, $email, $phone, $user_id];
    }
    
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute($params)) {
        $success = "Данные успешно обновлены";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Профиль пользователя</title>
    <style>
        .success { color: green; }
        .form-group { margin-bottom: 15px; }
    </style>
</head>
<body>
    <h2>Профиль пользователя</h2>
    
    <?php if (isset($success)): ?>
        <div class="success"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>ФИО:</label>
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>">
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
        </div>

        <div class="form-group">
            <label>Телефон:</label>
            <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
        </div>

        <div class="form-group">
            <label>Новый пароль (оставьте пустым, если не хотите менять):</label>
            <input type="password" name="new_password">
        </div>

        <button type="submit">Сохранить изменения</button>
    </form>
    
    <p><a href="logout.php">Выйти</a></p>
    <?php if (isAdmin()): ?>
        <p><a href="users.php">Управление пользователями</a></p>
    <?php endif; ?>
</body>
</html> 