<?php
$pageTitle = "Бронирование номера";
require_once 'config.php';
require_once 'header.php';

if (!isAuthenticated()) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['room_id'])) {
    header("Location: index.php");
    exit;
}

$room_id = $_GET['room_id'];
$stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_id = ? AND status = 'available'");
$stmt->execute([$room_id]);
$room = $stmt->fetch();

if (!$room) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    
    // Проверяем доступность номера на выбранные даты
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings 
                          WHERE room_id = ? AND status = 'confirmed'
                          AND ((check_in BETWEEN ? AND ?) 
                          OR (check_out BETWEEN ? AND ?))");
    $stmt->execute([$room_id, $check_in, $check_out, $check_in, $check_out]);
    
    if ($stmt->fetchColumn() == 0) {
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, room_id, check_in, check_out) 
                              VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$_SESSION['user_id'], $room_id, $check_in, $check_out])) {
            header("Location: my_bookings.php");
            exit;
        }
    } else {
        $error = "Номер недоступен на выбранные даты";
    }
}
?>

<style>
    .booking-container {
        max-width: 800px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .room-preview {
        display: flex;
        gap: 2rem;
        margin-bottom: 2rem;
        padding-bottom: 2rem;
        border-bottom: 1px solid #eee;
    }

    .room-image {
        width: 300px;
        height: 300px;
        object-fit: cover;
        border-radius: 8px;
    }

    .room-details {
        flex: 1;
    }

    .room-type {
        font-size: 1.5rem;
        color: #333;
        margin-bottom: 1rem;
    }

    .room-description {
        color: #666;
        margin-bottom: 1rem;
        line-height: 1.6;
    }

    .room-price {
        font-size: 1.25rem;
        color: #28a745;
        font-weight: bold;
        margin-bottom: 1rem;
    }

    .booking-form {
        max-width: 500px;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: #333;
        font-weight: 500;
    }

    .form-control {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
    }

    .form-control:focus {
        border-color: #28a745;
        outline: none;
        box-shadow: 0 0 0 2px rgba(40, 167, 69, 0.25);
    }

    .error-message {
        color: #dc3545;
        background: #f8d7da;
        padding: 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
    }

    .btn-book {
        background: #28a745;
        color: white;
        padding: 0.75rem 1.5rem;
        border: none;
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn-book:hover {
        background: #218838;
    }

    .price-calculator {
        margin-top: 1rem;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 4px;
    }
</style>

<div class="booking-container">
    <div class="room-preview">
        <?php if ($room['image_url']): ?>
            <img src="<?php echo htmlspecialchars($room['image_url']); ?>" 
                 alt="<?php echo htmlspecialchars($room['room_type']); ?>"
                 class="room-image">
        <?php endif; ?>
        
        <div class="room-details">
            <h2 class="room-type"><?php echo htmlspecialchars($room['room_type']); ?></h2>
            <p class="room-description"><?php echo htmlspecialchars($room['description']); ?></p>
            <div class="room-price"><?php echo number_format($room['price'], 2); ?> руб./сутки</div>
        </div>
    </div>

    <div class="booking-form">
        <h3>Бронирование</h3>
        
        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Дата заезда:</label>
                <input type="date" name="check_in" class="form-control" required 
                       min="<?php echo date('Y-m-d'); ?>"
                       onchange="calculatePrice()">
            </div>

            <div class="form-group">
                <label>Дата выезда:</label>
                <input type="date" name="check_out" class="form-control" required 
                       min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>"
                       onchange="calculatePrice()">
            </div>

            <div class="price-calculator" id="priceCalculator" style="display: none;">
                <p>Стоимость проживания: <span id="totalPrice">0</span> руб.</p>
            </div>

            <button type="submit" class="btn-book">Забронировать</button>
        </form>
    </div>
</div>

<script>
function calculatePrice() {
    const checkIn = document.querySelector('input[name="check_in"]').value;
    const checkOut = document.querySelector('input[name="check_out"]').value;
    const pricePerDay = <?php echo $room['price']; ?>;
    
    if (checkIn && checkOut) {
        const start = new Date(checkIn);
        const end = new Date(checkOut);
        const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
        
        if (days > 0) {
            const total = days * pricePerDay;
            document.getElementById('totalPrice').textContent = total.toLocaleString('ru-RU', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
            document.getElementById('priceCalculator').style.display = 'block';
        }
    }
}
</script>

<?php require_once 'footer.php'; ?> 