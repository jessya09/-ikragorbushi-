<?php
$pageTitle = "Номера";
require_once 'config.php';
require_once 'header.php';

// Получаем список всех номеров
$stmt = $pdo->query("SELECT * FROM rooms ORDER BY price");
$rooms = $stmt->fetchAll();
?>

<style>
    .rooms-container {
        padding: 2rem 0;
    }
    .rooms-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 2rem;
        padding: 1rem;
    }
    .room-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
    }
    .room-card:hover {
        transform: translateY(-5px);
    }
    .room-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
    }
    .room-info {
        padding: 1.5rem;
    }
    .room-type {
        font-size: 1.25rem;
        margin-bottom: 0.5rem;
        color: #333;
    }
    .room-number {
        color: #666;
        margin-bottom: 1rem;
    }
    .room-description {
        color: #666;
        margin-bottom: 1rem;
        line-height: 1.6;
    }
    .room-price {
        font-size: 1.25rem;
        color: #28a745;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    .room-status {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 3px;
        font-size: 0.875rem;
        margin-bottom: 1rem;
    }
    .status-available {
        background: #d4edda;
        color: #155724;
    }
    .status-occupied {
        background: #f8d7da;
        color: #721c24;
    }
    .status-maintenance {
        background: #fff3cd;
        color: #856404;
    }
    .book-btn {
        display: inline-block;
        padding: 0.5rem 1rem;
        background: #28a745;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        transition: background-color 0.3s;
    }
    .book-btn:hover {
        background: #218838;
    }
    .login-prompt {
        color: #666;
        font-style: italic;
    }
</style>

<div class="rooms-container">
    <h1 style="text-align: center; margin-bottom: 2rem;">Наши номера</h1>
    
    <div class="rooms-grid">
        <?php foreach ($rooms as $room): ?>
            <div class="room-card">
                <?php if ($room['image_url']): ?>
                    <img src="<?php echo htmlspecialchars($room['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($room['room_type']); ?>"
                         class="room-image">
                <?php endif; ?>
                
                <div class="room-info">
                    <h2 class="room-type"><?php echo htmlspecialchars($room['room_type']); ?></h2>
                    <div class="room-number">Номер <?php echo htmlspecialchars($room['room_number']); ?></div>
                    <p class="room-description"><?php echo htmlspecialchars($room['description']); ?></p>
                    <div class="room-price"><?php echo number_format($room['price'], 2); ?> руб./сутки</div>
                    
                    <div class="room-status status-<?php echo $room['status']; ?>">
                        <?php
                        switch($room['status']) {
                            case 'available':
                                echo 'Доступен';
                                break;
                            case 'occupied':
                                echo 'Занят';
                                break;
                            case 'maintenance':
                                echo 'На обслуживании';
                                break;
                        }
                        ?>
                    </div>
                    
                    <?php if ($room['status'] == 'available'): ?>
                        <?php if (isAuthenticated()): ?>
                            <a href="book.php?room_id=<?php echo $room['room_id']; ?>" class="book-btn">
                                Забронировать
                            </a>
                        <?php else: ?>
                            <p class="login-prompt">
                                <a href="login.php">Войдите</a> или 
                                <a href="register.php">зарегистрируйтесь</a> 
                                для бронирования
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'footer.php'; ?> 