<?php
$pageTitle = "Профиль пользователя";
require_once 'config.php';
require_once 'header.php';

if (!isAuthenticated()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    if (!empty($_POST['new_password'])) {
        $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, password = ? WHERE user_id = ?";
        $params = [$full_name, $email, $phone, $password, $user_id];
    } else {
        $sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?";
        $params = [$full_name, $email, $phone, $user_id];
    }
    
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute($params)) {
        $success = "Данные успешно обновлены";
        
        // Обновляем данные пользователя для отображения
        $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        // Обновляем имя пользователя в сессии
        $_SESSION['user_name'] = $full_name;
    }
}
?>

<div class="profile-form" style="max-width: 600px; margin: 2rem auto; padding: 2rem; background: white; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
    <h2>Профиль пользователя</h2>
    
    <?php if (isset($success)): ?>
        <div class="success" style="color: green; margin-bottom: 1rem;"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>ФИО:</label>
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" class="form-control">
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="form-control">
        </div>

        <div class="form-group">
            <label>Телефон:</label>
            <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" class="form-control">
        </div>

        <div class="form-group">
            <label>Новый пароль (оставьте пустым, если не хотите менять):</label>
            <input type="password" name="new_password" class="form-control">
        </div>

        <button type="submit" class="btn">Сохранить изменения</button>
    </form>
</div>

<style>
    .form-group {
        margin-bottom: 1rem;
    }
    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
    }
    .form-control {
        width: 100%;
        padding: 0.5rem;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    .btn {
        background: #28a745;
        color: white;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn:hover {
        background: #218838;
    }
</style>

<?php require_once 'footer.php'; ?> 