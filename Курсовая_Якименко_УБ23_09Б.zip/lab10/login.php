<?php
$pageTitle = "Вход";
require_once 'config.php';
require_once 'header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user_role'] = $user['role_id'];
        $_SESSION['user_name'] = $user['full_name'];
        
        debug([
            'user_id' => $_SESSION['user_id'],
            'user_role' => $_SESSION['user_role'],
            'is_admin' => isAdmin()
        ]);
        
        header("Location: index.php");
        exit;
    } else {
        $error = "Неверный логин или пароль";
    }
}
?>

<div class="login-form" style="max-width: 400px; margin: 2rem auto; padding: 2rem; background: white; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
    <h2>Вход в систему</h2>
    
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Логин:</label>
            <input type="text" name="login" class="form-control">
        </div>

        <div class="form-group">
            <label>Пароль:</label>
            <input type="password" name="password" class="form-control">
        </div>

        <button type="submit" class="btn">Войти</button>
    </form>
    
    <p style="margin-top: 1rem;">Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>
</div>

<?php require_once 'footer.php'; ?> 