<?php
$pageTitle = "Управление номерами";
require_once '../config.php';
require_once '../header.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit;
}

// Обработка добавления/редактирования номера
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $room_id = isset($_POST['room_id']) ? $_POST['room_id'] : null;
    $room_number = trim($_POST['room_number']);
    $room_type = trim($_POST['room_type']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $status = $_POST['status'];

    // Загрузка изображения
    $image_url = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/rooms/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = 'uploads/rooms/' . $new_filename;
        }
    }

    if ($room_id) {
        // Обновление существующего номера
        $sql = "UPDATE rooms SET room_number = ?, room_type = ?, description = ?, 
                price = ?, status = ?";
        $params = [$room_number, $room_type, $description, $price, $status];
        
        if ($image_url) {
            $sql .= ", image_url = ?";
            $params[] = $image_url;
        }
        
        $sql .= " WHERE room_id = ?";
        $params[] = $room_id;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    } else {
        // Добавление нового номера
        $stmt = $pdo->prepare("INSERT INTO rooms (room_number, room_type, description, price, status, image_url) 
                              VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$room_number, $room_type, $description, $price, $status, $image_url]);
    }
    
    header("Location: rooms_manage.php");
    exit;
}

// Получение списка всех номеров
$stmt = $pdo->query("SELECT * FROM rooms ORDER BY room_number");
$rooms = $stmt->fetchAll();
?>

<h2>Управление номерами</h2>

<style>
    .rooms-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 1rem;
        margin-top: 1rem;
    }
    .room-card {
        background: white;
        padding: 1rem;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .room-card img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 5px;
    }
    .add-room-form {
        background: white;
        padding: 1rem;
        border-radius: 5px;
        margin-bottom: 1rem;
    }
    .form-group {
        margin-bottom: 1rem;
    }
    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
    }
    .form-group input, .form-group select, .form-group textarea {
        width: 100%;
        padding: 0.5rem;
        border: 1px solid #ddd;
        border-radius: 3px;
    }
</style>

<div class="add-room-form">
    <h3>Добавить новый номер</h3>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Номер комнаты:</label>
            <input type="text" name="room_number" required>
        </div>
        
        <div class="form-group">
            <label>Тип номера:</label>
            <input type="text" name="room_type" required>
        </div>
        
        <div class="form-group">
            <label>Описание:</label>
            <textarea name="description" rows="4"></textarea>
        </div>
        
        <div class="form-group">
            <label>Цена за сутки:</label>
            <input type="number" name="price" step="0.01" required>
        </div>
        
        <div class="form-group">
            <label>Статус:</label>
            <select name="status">
                <option value="available">Доступен</option>
                <option value="occupied">Занят</option>
                <option value="maintenance">На обслуживании</option>
            </select>
        </div>
        
        <div class="form-group">
            <label>Изображение:</label>
            <input type="file" name="image" accept="image/*">
        </div>
        
        <button type="submit" class="btn">Добавить номер</button>
    </form>
</div>

<div class="rooms-grid">
    <?php foreach ($rooms as $room): ?>
        <div class="room-card">
            <?php if ($room['image_url']): ?>
                <img src="../<?php echo htmlspecialchars($room['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($room['room_type']); ?>">
            <?php endif; ?>
            <h3>Номер <?php echo htmlspecialchars($room['room_number']); ?></h3>
            <p><strong>Тип:</strong> <?php echo htmlspecialchars($room['room_type']); ?></p>
            <p><strong>Цена:</strong> <?php echo number_format($room['price'], 2); ?> руб./сутки</p>
            <p><strong>Статус:</strong> <?php echo htmlspecialchars($room['status']); ?></p>
            <p><?php echo htmlspecialchars($room['description']); ?></p>
            <a href="edit_room.php?id=<?php echo $room['room_id']; ?>" class="btn">Редактировать</a>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once '../footer.php'; ?> 