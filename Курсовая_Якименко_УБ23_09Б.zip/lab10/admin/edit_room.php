<?php
$pageTitle = "Редактирование номера";
require_once '../config.php';
require_once '../header.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: rooms_manage.php");
    exit;
}

$room_id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_id = ?");
$stmt->execute([$room_id]);
$room = $stmt->fetch();

if (!$room) {
    header("Location: rooms_manage.php");
    exit;
}
?>

<style>
    .edit-form {
        background: white;
        padding: 2rem;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 0 auto;
    }
    .current-image {
        max-width: 300px;
        margin: 1rem 0;
    }
    .current-image img {
        width: 100%;
        height: auto;
        border-radius: 5px;
    }
</style>

<div class="edit-form">
    <h2>Редактирование номера <?php echo htmlspecialchars($room['room_number']); ?></h2>

    <form method="POST" action="rooms_manage.php" enctype="multipart/form-data">
        <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
        
        <div class="form-group">
            <label>Номер комнаты:</label>
            <input type="text" name="room_number" value="<?php echo htmlspecialchars($room['room_number']); ?>" required>
        </div>
        
        <div class="form-group">
            <label>Тип номера:</label>
            <input type="text" name="room_type" value="<?php echo htmlspecialchars($room['room_type']); ?>" required>
        </div>
        
        <div class="form-group">
            <label>Описание:</label>
            <textarea name="description" rows="4"><?php echo htmlspecialchars($room['description']); ?></textarea>
        </div>
        
        <div class="form-group">
            <label>Цена за сутки:</label>
            <input type="number" name="price" step="0.01" value="<?php echo $room['price']; ?>" required>
        </div>
        
        <div class="form-group">
            <label>Статус:</label>
            <select name="status">
                <option value="available" <?php echo $room['status'] == 'available' ? 'selected' : ''; ?>>Доступен</option>
                <option value="occupied" <?php echo $room['status'] == 'occupied' ? 'selected' : ''; ?>>Занят</option>
                <option value="maintenance" <?php echo $room['status'] == 'maintenance' ? 'selected' : ''; ?>>На обслуживании</option>
            </select>
        </div>
        
        <?php if ($room['image_url']): ?>
            <div class="current-image">
                <p>Текущее изображение:</p>
                <img src="../<?php echo htmlspecialchars($room['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($room['room_type']); ?>">
            </div>
        <?php endif; ?>
        
        <div class="form-group">
            <label>Новое изображение (оставьте пустым, чтобы сохранить текущее):</label>
            <input type="file" name="image" accept="image/*">
        </div>
        
        <button type="submit" class="btn">Сохранить изменения</button>
        <a href="rooms_manage.php" class="btn" style="background: #6c757d;">Отмена</a>
    </form>
</div>

<?php require_once '../footer.php'; ?> 