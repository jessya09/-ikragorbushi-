<?php
$pageTitle = "Управление бронированиями";
require_once '../config.php';
require_once 'header.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit;
}

// Обработка действий с бронированием
if (isset($_POST['action']) && isset($_POST['booking_id'])) {
    $booking_id = $_POST['booking_id'];
    
    switch($_POST['action']) {
        case 'confirm':
            $stmt = $pdo->prepare("UPDATE bookings SET status = 'confirmed' WHERE booking_id = ?");
            $stmt->execute([$booking_id]);
            break;
            
        case 'cancel':
            $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE booking_id = ?");
            $stmt->execute([$booking_id]);
            break;
            
        case 'delete':
            $stmt = $pdo->prepare("DELETE FROM bookings WHERE booking_id = ?");
            $stmt->execute([$booking_id]);
            break;
    }
    
    header("Location: bookings_manage.php");
    exit;
}

// Получение списка всех бронирований
$stmt = $pdo->query("SELECT b.*, r.room_type, r.room_number, r.price, r.image_url,
                            u.full_name, u.email, u.phone
                     FROM bookings b 
                     JOIN rooms r ON b.room_id = r.room_id
                     JOIN users u ON b.user_id = u.user_id
                     ORDER BY b.created_at DESC");
$bookings = $stmt->fetchAll();
?>

<style>
    .bookings-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 1rem;
    }

    .booking-card {
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        overflow: hidden;
    }

    .booking-header {
        display: flex;
        align-items: center;
        padding: 1.5rem;
        border-bottom: 1px solid #eee;
        background: #f8f9fa;
    }

    .booking-image {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 4px;
        margin-right: 1.5rem;
    }

    .booking-details {
        flex: 1;
    }

    .booking-user {
        margin-left: auto;
        text-align: right;
    }

    .booking-content {
        padding: 1.5rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .booking-dates {
        flex: 1;
    }

    .booking-actions {
        display: flex;
        gap: 0.5rem;
    }

    .btn {
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 0.9rem;
        transition: background-color 0.3s;
    }

    .btn-confirm {
        background: #28a745;
        color: white;
    }

    .btn-cancel {
        background: #dc3545;
        color: white;
    }

    .btn-delete {
        background: #6c757d;
        color: white;
    }

    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 4px;
        font-size: 0.875rem;
        font-weight: 500;
    }

    .status-pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-confirmed {
        background: #d4edda;
        color: #155724;
    }

    .status-cancelled {
        background: #f8d7da;
        color: #721c24;
    }
</style>

<div class="bookings-container">
    <h2>Управление бронированиями</h2>
    
    <?php foreach ($bookings as $booking): ?>
        <div class="booking-card">
            <div class="booking-header">
                <?php if ($booking['image_url']): ?>
                    <img src="../<?php echo htmlspecialchars($booking['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($booking['room_type']); ?>"
                         class="booking-image">
                <?php endif; ?>
                
                <div class="booking-details">
                    <h3><?php echo htmlspecialchars($booking['room_type']); ?></h3>
                    <div>Номер <?php echo htmlspecialchars($booking['room_number']); ?></div>
                </div>
                
                <div class="booking-user">
                    <div><strong><?php echo htmlspecialchars($booking['full_name']); ?></strong></div>
                    <div><?php echo htmlspecialchars($booking['email']); ?></div>
                    <div><?php echo htmlspecialchars($booking['phone']); ?></div>
                </div>
            </div>
            
            <div class="booking-content">
                <div class="booking-dates">
                    <div>
                        <strong>Заезд:</strong> 
                        <?php echo date('d.m.Y', strtotime($booking['check_in'])); ?>
                    </div>
                    <div>
                        <strong>Выезд:</strong> 
                        <?php echo date('d.m.Y', strtotime($booking['check_out'])); ?>
                    </div>
                    <?php 
                    $days = max(1, round((strtotime($booking['check_out']) - strtotime($booking['check_in'])) / (60 * 60 * 24)));
                    $total = $booking['price'] * $days;
                    ?>
                    <div>
                        <strong>Стоимость:</strong> 
                        <?php echo number_format($total, 2); ?> руб.
                    </div>
                </div>
                
                <div class="status-badge status-<?php echo $booking['status']; ?>">
                    <?php
                    switch($booking['status']) {
                        case 'pending':
                            echo 'Ожидает подтверждения';
                            break;
                        case 'confirmed':
                            echo 'Подтверждено';
                            break;
                        case 'cancelled':
                            echo 'Отменено';
                            break;
                    }
                    ?>
                </div>
                
                <div class="booking-actions">
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="booking_id" value="<?php echo $booking['booking_id']; ?>">
                        
                        <?php if ($booking['status'] != 'confirmed'): ?>
                            <button type="submit" name="action" value="confirm" class="btn btn-confirm">
                                Подтвердить
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($booking['status'] != 'cancelled'): ?>
                            <button type="submit" name="action" value="cancel" class="btn btn-cancel">
                                Отменить
                            </button>
                        <?php endif; ?>
                        
                        <button type="submit" name="action" value="delete" class="btn btn-delete" 
                                onclick="return confirm('Вы уверены, что хотите удалить это бронирование?')">
                            Удалить
                        </button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once 'footer.php'; ?> 