    </div>
    <footer style="background: #333; color: #fff; padding: 1rem; text-align: center; margin-top: auto;">
        <p>&copy; <?php echo date('Y'); ?> Гостиница "Уют". Все права защищены.</p>
        <p>Адрес: ул. Примерная, 123</p>
        <p>Телефон: +7 (999) 123-45-67</p>
    </footer>
</body>
</html> 