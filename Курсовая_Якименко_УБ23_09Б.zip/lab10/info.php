<?php
phpinfo();
?> 