<?php
$pageTitle = "Главная";
require_once 'config.php';
require_once 'header.php';

// Получаем список доступных номеров
$stmt = $pdo->query("SELECT * FROM rooms WHERE status = 'available'");
$rooms = $stmt->fetchAll();
?>

<style>
    .rooms-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1rem;
        padding: 1rem;
    }
    .room-card {
        background: #fff;
        padding: 1rem;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .room-card img {
        width: 300px;          /* Фиксированная ширина */
        height: 300px;         /* Фиксированная высота */
        object-fit: cover;     /* Сохраняет пропорции, обрезая лишнее */
        border-radius: 5px;
        display: block;        /* Убирает пробел под изображением */
        margin: 0 auto;        /* Центрирует изображение */
    }
    .room-card h3 {
        margin: 1rem 0;
    }
    .price {
        color: #28a745;
        font-size: 1.2rem;
        font-weight: bold;
    }
    .btn {
        display: inline-block;
        padding: 0.5rem 1rem;
        background: #28a745;
        color: #fff;
        text-decoration: none;
        border-radius: 3px;
        margin-top: 1rem;
    }
</style>

<h2>Доступные номера</h2>
<div class="rooms-grid">
    <?php foreach ($rooms as $room): ?>
        <div class="room-card">
            <?php if ($room['image_url']): ?>
                <img src="<?php echo htmlspecialchars($room['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($room['room_type']); ?>">
            <?php endif; ?>
            <h3><?php echo htmlspecialchars($room['room_type']); ?></h3>
            <p><?php echo htmlspecialchars($room['description']); ?></p>
            <div class="price">
                <?php echo number_format($room['price'], 2); ?> руб./сутки
            </div>
            <?php if (isAuthenticated()): ?>
                <a href="book.php?room_id=<?php echo $room['room_id']; ?>" class="btn">
                    Забронировать
                </a>
            <?php else: ?>
                <a href="login.php" class="btn">Войти для бронирования</a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once 'footer.php'; ?> 