<?php
// Определяем базовый путь
$base_path = '/lab8';
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo isset($pageTitle) ? $pageTitle . " - Гостиница Уют" : "Гостиница Уют"; ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        .nav {
            background: #444;
            padding: 1rem;
            text-align: center;
        }

        .nav a {
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            margin: 0 0.5rem;
            border-radius: 3px;
            transition: background-color 0.3s;
        }

        .nav a:hover {
            background-color: #555;
        }

        .container {
            width: 90%;
            margin: auto;
            padding: 1rem;
            flex: 1;
        }

        @media (max-width: 768px) {
            .nav {
                padding: 0.5rem;
            }
            .nav a {
                display: inline-block;
                margin: 0.2rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Гостиница "Уют"</h1>
    </div>

    <div class="nav">
        <a href="<?php echo $base_path; ?>/index.php">Главная</a>
        <a href="<?php echo $base_path; ?>/rooms.php">Номера</a>
        <?php if (isAuthenticated()): ?>
            <a href="<?php echo $base_path; ?>/profile.php">Профиль</a>
            <a href="<?php echo $base_path; ?>/my_bookings.php">Мои бронирования</a>
            <?php if (isAdmin()): ?>
                <a href="<?php echo $base_path; ?>/admin/rooms_manage.php">Управление номерами</a>
                <a href="<?php echo $base_path; ?>/users.php">Пользователи</a>
            <?php endif; ?>
            <a href="<?php echo $base_path; ?>/logout.php">Выход</a>
        <?php else: ?>
            <a href="<?php echo $base_path; ?>/login.php">Вход</a>
            <a href="<?php echo $base_path; ?>/register.php">Регистрация</a>
        <?php endif; ?>
    </div>

    <div class="container"> 