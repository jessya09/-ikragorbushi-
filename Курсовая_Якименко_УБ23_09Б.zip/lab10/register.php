<?php
$pageTitle = "Регистрация";
require_once 'config.php';
require_once 'header.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    // Валидация
    if (empty($login)) $errors[] = "Логин обязателен";
    if (empty($password)) $errors[] = "Пароль обязателен";
    if (empty($full_name)) $errors[] = "ФИО обязательно";
    if (empty($email)) $errors[] = "Email обязателен";
    
    // Проверка уникальности логина и email
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = ? OR email = ?");
    $stmt->execute([$login, $email]);
    if ($stmt->fetchColumn() > 0) {
        $errors[] = "Пользователь с таким логином или email уже существует";
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, email, phone, role_id) 
                              VALUES (?, ?, ?, ?, ?, 2)");
        if ($stmt->execute([$login, $hashed_password, $full_name, $email, $phone])) {
            header("Location: login.php");
            exit;
        }
    }
}
?>

<style>
    .register-container {
        max-width: 500px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .register-title {
        text-align: center;
        color: #333;
        margin-bottom: 2rem;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: #555;
        font-weight: 500;
    }

    .form-control {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
        transition: border-color 0.3s ease;
    }

    .form-control:focus {
        border-color: #28a745;
        outline: none;
        box-shadow: 0 0 0 2px rgba(40, 167, 69, 0.25);
    }

    .error-list {
        background: #f8d7da;
        color: #721c24;
        padding: 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
    }

    .error-list ul {
        margin: 0;
        padding-left: 1.5rem;
    }

    .error-list li {
        margin-bottom: 0.5rem;
    }

    .error-list li:last-child {
        margin-bottom: 0;
    }

    .btn-register {
        width: 100%;
        padding: 0.75rem;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn-register:hover {
        background: #218838;
    }

    .login-link {
        text-align: center;
        margin-top: 1rem;
    }

    .login-link a {
        color: #28a745;
        text-decoration: none;
    }

    .login-link a:hover {
        text-decoration: underline;
    }

    /* Анимация для полей ввода */
    .form-control:focus {
        transform: translateY(-2px);
        transition: transform 0.3s ease;
    }

    /* Стили для обязательных полей */
    .required::after {
        content: '*';
        color: #dc3545;
        margin-left: 4px;
    }
</style>

<div class="register-container">
    <h2 class="register-title">Регистрация нового пользователя</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="error-list">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label class="required">Логин:</label>
            <input type="text" name="login" class="form-control" 
                   value="<?php echo isset($_POST['login']) ? htmlspecialchars($_POST['login']) : ''; ?>"
                   required>
        </div>

        <div class="form-group">
            <label class="required">Пароль:</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="form-group">
            <label class="required">ФИО:</label>
            <input type="text" name="full_name" class="form-control"
                   value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>"
                   required>
        </div>

        <div class="form-group">
            <label class="required">Email:</label>
            <input type="email" name="email" class="form-control"
                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                   required>
        </div>

        <div class="form-group">
            <label>Телефон:</label>
            <input type="tel" name="phone" class="form-control"
                   value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
        </div>

        <button type="submit" class="btn-register">Зарегистрироваться</button>
    </form>
    
    <div class="login-link">
        Уже есть аккаунт? <a href="login.php">Войти</a>
    </div>
</div>

<?php require_once 'footer.php'; ?>  