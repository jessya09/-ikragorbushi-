<?php
$pageTitle = "Мои бронирования";
require_once 'config.php';
require_once 'header.php';

if (!isAuthenticated()) {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->prepare("SELECT b.*, r.room_type, r.room_number, r.price, r.image_url 
                       FROM bookings b 
                       JOIN rooms r ON b.room_id = r.room_id 
                       WHERE b.user_id = ? 
                       ORDER BY b.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();
?>

<style>
    .bookings-container {
        max-width: 1000px;
        margin: 2rem auto;
        padding: 1rem;
    }

    .booking-card {
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        overflow: hidden;
    }

    .booking-header {
        display: flex;
        align-items: center;
        padding: 1.5rem;
        border-bottom: 1px solid #eee;
    }

    .booking-image {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border-radius: 4px;
        margin-right: 1.5rem;
    }

    .booking-details {
        flex: 1;
    }

    .room-type {
        font-size: 1.25rem;
        color: #333;
        margin-bottom: 0.5rem;
    }

    .room-number {
        color: #666;
        margin-bottom: 0.5rem;
    }

    .booking-info {
        padding: 1.5rem;
        background: #f8f9fa;
    }

    .booking-dates {
        display: flex;
        justify-content: space-between;
        margin-bottom: 1rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }

    .date-group {
        flex: 1;
    }

    .date-label {
        color: #666;
        font-size: 0.875rem;
        margin-bottom: 0.25rem;
    }

    .date-value {
        font-size: 1.1rem;
        color: #333;
    }

    .booking-price {
        font-size: 1.25rem;
        color: #28a745;
        font-weight: bold;
        margin-top: 1rem;
    }

    .booking-status {
        display: inline-block;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        font-size: 0.875rem;
        font-weight: 500;
        margin-top: 1rem;
    }

    .status-pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-confirmed {
        background: #d4edda;
        color: #155724;
    }

    .status-cancelled {
        background: #f8d7da;
        color: #721c24;
    }

    .no-bookings {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .no-bookings h3 {
        color: #666;
        margin-bottom: 1rem;
    }

    .btn-book-now {
        display: inline-block;
        padding: 0.75rem 1.5rem;
        background: #28a745;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        transition: background-color 0.3s;
    }

    .btn-book-now:hover {
        background: #218838;
        text-decoration: none;
        color: white;
    }
</style>

<div class="bookings-container">
    <h2>Мои бронирования</h2>
    
    <?php if (empty($bookings)): ?>
        <div class="no-bookings">
            <h3>У вас пока нет бронирований</h3>
            <a href="rooms.php" class="btn-book-now">Забронировать номер</a>
        </div>
    <?php else: ?>
        <?php foreach ($bookings as $booking): ?>
            <div class="booking-card">
                <div class="booking-header">
                    <?php if ($booking['image_url']): ?>
                        <img src="<?php echo htmlspecialchars($booking['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($booking['room_type']); ?>"
                             class="booking-image">
                    <?php endif; ?>
                    
                    <div class="booking-details">
                        <h3 class="room-type"><?php echo htmlspecialchars($booking['room_type']); ?></h3>
                        <div class="room-number">Номер <?php echo htmlspecialchars($booking['room_number']); ?></div>
                    </div>
                </div>

                <div class="booking-info">
                    <div class="booking-dates">
                        <div class="date-group">
                            <div class="date-label">Дата заезда</div>
                            <div class="date-value">
                                <?php echo date('d.m.Y', strtotime($booking['check_in'])); ?>
                            </div>
                        </div>
                        <div class="date-group">
                            <div class="date-label">Дата выезда</div>
                            <div class="date-value">
                                <?php echo date('d.m.Y', strtotime($booking['check_out'])); ?>
                            </div>
                        </div>
                    </div>

                    <?php 
                    $days = (strtotime($booking['check_out']) - strtotime($booking['check_in'])) / (60 * 60 * 24);
                    $total = $booking['price'] * $days;
                    ?>
                    <div class="booking-price">
                        Стоимость: <?php echo number_format($total, 2); ?> руб.
                        <span style="font-size: 0.875rem; color: #666;">
                            (<?php echo $days; ?> <?php echo getDaysWord($days); ?> × 
                            <?php echo number_format($booking['price'], 2); ?> руб.)
                        </span>
                    </div>

                    <div class="booking-status status-<?php echo $booking['status']; ?>">
                        <?php
                        switch($booking['status']) {
                            case 'pending':
                                echo 'Ожидает подтверждения';
                                break;
                            case 'confirmed':
                                echo 'Подтверждено';
                                break;
                            case 'cancelled':
                                echo 'Отменено';
                                break;
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php
function getDaysWord($number) {
    $cases = [2, 0, 1, 1, 1, 2];
    $words = ['день', 'дня', 'дней'];
    return $words[($number % 100 > 4 && $number % 100 < 20) ? 2 : $cases[min($number % 10, 5)]];
}
?>

<?php require_once 'footer.php'; ?> 