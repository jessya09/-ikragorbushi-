<?php
echo "Hello, World!";
?> 