    </div>
    <div class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Контакты</h3>
                <p>Телефон: +7 (999) 123-45-67</p>
                <p>Email: info@hotel-uyt.ru</p>
                <p>Адрес: г. Москва, ул. Примерная, 123</p>
            </div>
            <div class="footer-section">
                <h3>Информация</h3>
                <p><a href="#">О нас</a></p>
                <p><a href="#">Правила проживания</a></p>
                <p><a href="#">Политика конфиденциальности</a></p>
            </div>
            <div class="footer-section">
                <h3>Мы в соцсетях</h3>
                <p><a href="#">VKontakte</a></p>
                <p><a href="#">Telegram</a></p>
                <p><a href="#">Instagram</a></p>
            </div>
        </div>
        <div style="margin-top: 1rem;">
            &copy; <?php echo date('Y'); ?> Гостиница "Уют". Все права защищены.
        </div>
    </div>
</body>
</html> 