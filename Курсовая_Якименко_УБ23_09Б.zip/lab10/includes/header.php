<!DOCTYPE html>
<html>
<head>
    <title><?php echo isset($pageTitle) ? $pageTitle . " - Гостиница Уют" : "Гостиница Уют"; ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        .nav {
            background: #444;
            padding: 0.5rem;
            text-align: right;
        }

        .nav a {
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            display: inline-block;
        }

        .nav a:hover {
            background: #555;
        }

        .container {
            width: 90%;
            margin: auto;
            padding: 1rem;
            flex: 1;
        }

        .footer {
            background: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: auto;
        }

        .footer-content {
            display: flex;
            justify-content: space-around;
            max-width: 1200px;
            margin: 0 auto;
        }

        .footer-section {
            flex: 1;
            padding: 0 1rem;
        }

        .footer-section h3 {
            margin-bottom: 0.5rem;
        }

        .footer-section p, .footer-section a {
            color: #fff;
            text-decoration: none;
        }

        @media (max-width: 768px) {
            .footer-content {
                flex-direction: column;
                text-align: center;
            }
            .footer-section {
                margin: 1rem 0;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Гостиница "Уют"</h1>
    </div>

    <div class="nav">
        <a href="index.php">Главная</a>
        <?php if (isAuthenticated()): ?>
            <a href="profile.php">Профиль</a>
            <a href="my_bookings.php">Мои бронирования</a>
            <?php if (isAdmin()): ?>
                <a href="admin/rooms.php">Управление номерами</a>
                <a href="users.php">Пользователи</a>
            <?php endif; ?>
            <a href="logout.php">Выход</a>
        <?php else: ?>
            <a href="login.php">Вход</a>
            <a href="register.php">Регистрация</a>
        <?php endif; ?>
    </div>

    <div class="container"> 