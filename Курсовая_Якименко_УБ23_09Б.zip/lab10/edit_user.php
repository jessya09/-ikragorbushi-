<?php
require_once 'config.php';

if (!isAdmin()) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit;
}

$user_id = $_GET['id'];
$errors = [];

// Получаем данные пользователя
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: users.php");
    exit;
}

// Получаем список всех ролей
$stmt = $pdo->query("SELECT * FROM roles");
$roles = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role_id = $_POST['role_id'];
    
    // Валидация
    if (empty($full_name)) $errors[] = "ФИО обязательно для заполнения";
    if (empty($email)) $errors[] = "Email обязателен для заполнения";
    
    // Проверка email на уникальность (исключая текущего пользователя)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ?");
    $stmt->execute([$email, $user_id]);
    if ($stmt->fetchColumn() > 0) {
        $errors[] = "Пользователь с таким email уже существует";
    }
    
    if (empty($errors)) {
        // Если указан новый пароль, обновляем его
        if (!empty($_POST['new_password'])) {
            $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, role_id = ?, password = ? WHERE user_id = ?";
            $params = [$full_name, $email, $phone, $role_id, $password, $user_id];
        } else {
            $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, role_id = ? WHERE user_id = ?";
            $params = [$full_name, $email, $phone, $role_id, $user_id];
        }
        
        $stmt = $pdo->prepare($sql);
        if ($stmt->execute($params)) {
            $success = "Данные пользователя успешно обновлены";
            
            // Обновляем данные пользователя для отображения
            $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Редактирование пользователя</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
        .success {
            color: green;
            margin-bottom: 10px;
        }
        .btn {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Редактирование пользователя</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="error">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>ФИО:</label>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>">
            </div>

            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
            </div>

            <div class="form-group">
                <label>Телефон:</label>
                <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
            </div>

            <div class="form-group">
                <label>Роль:</label>
                <select name="role_id">
                    <?php foreach ($roles as $role): ?>
                        <option value="<?php echo $role['role_id']; ?>" 
                                <?php echo $user['role_id'] == $role['role_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($role['role_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Новый пароль (оставьте пустым, если не хотите менять):</label>
                <input type="password" name="new_password">
            </div>

            <button type="submit" class="btn">Сохранить изменения</button>
        </form>
        
        <p><a href="users.php">Вернуться к списку пользователей</a></p>
    </div>
</body>
</html> 