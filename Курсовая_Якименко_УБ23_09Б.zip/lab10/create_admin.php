<?php
require_once 'config.php';

// Проверяем, существует ли уже админ
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role_id = 1");
if ($stmt->fetchColumn() > 0) {
    die("Администратор уже существует!");
}

// Создаем роль админа, если её нет
$stmt = $pdo->query("SELECT COUNT(*) FROM roles WHERE role_id = 1");
if ($stmt->fetchColumn() == 0) {
    $stmt = $pdo->prepare("INSERT INTO roles (role_id, role_name) VALUES (1, 'admin')");
    $stmt->execute();
}

// Создаем роль пользователя, если её нет
$stmt = $pdo->query("SELECT COUNT(*) FROM roles WHERE role_id = 2");
if ($stmt->fetchColumn() == 0) {
    $stmt = $pdo->prepare("INSERT INTO roles (role_id, role_name) VALUES (2, 'user')");
    $stmt->execute();
}

// Создаем администратора
$password = 'admin123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$admin_data = [
    'login' => 'admin',
    'password' => $hashed_password,
    'full_name' => 'Administrator',
    'email' => 'admin@hotel.com',
    'phone' => '+79999999999',
    'role_id' => 1
];

$stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, email, phone, role_id) 
                       VALUES (:login, :password, :full_name, :email, :phone, :role_id)");

if ($stmt->execute($admin_data)) {
    echo "Администратор успешно создан!<br>";
    echo "Логин: admin<br>";
    echo "Пароль: " . $password . "<br>";
    echo "Хешированный пароль: " . $hashed_password;
} else {
    echo "Ошибка при создании администратора";
}

// После создания админа удалите этот файл! 