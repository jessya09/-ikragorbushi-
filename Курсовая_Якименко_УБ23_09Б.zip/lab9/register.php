<?php
require_once 'config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    // Валидация
    if (empty($login)) $errors[] = "Логин обязателен";
    if (empty($password)) $errors[] = "Пароль обязателен";
    if (empty($full_name)) $errors[] = "ФИО обязательно";
    if (empty($email)) $errors[] = "Email обязателен";
    
    // Проверка уникальности логина и email
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = ? OR email = ?");
    $stmt->execute([$login, $email]);
    if ($stmt->fetchColumn() > 0) {
        $errors[] = "Пользователь с таким логином или email уже существует";
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, email, phone) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$login, $hashed_password, $full_name, $email, $phone])) {
            header("Location: login.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Регистрация</title>
    <style>
        .error { color: red; }
        .form-group { margin-bottom: 15px; }
    </style>
</head>
<body>
    <h2>Регистрация нового пользователя</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <?php foreach ($errors as $error): ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Логин:</label>
            <input type="text" name="login" value="<?php echo isset($_POST['login']) ? htmlspecialchars($_POST['login']) : ''; ?>">
        </div>

        <div class="form-group">
            <label>Пароль:</label>
            <input type="password" name="password">
        </div>

        <div class="form-group">
            <label>ФИО:</label>
            <input type="text" name="full_name" value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>

        <div class="form-group">
            <label>Телефон:</label>
            <input type="tel" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
        </div>

        <button type="submit">Зарегистрироваться</button>
    </form>
</body>
</html>  