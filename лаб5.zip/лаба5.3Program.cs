﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите первое слово:");
        string word1 = Console.ReadLine();

        Console.WriteLine("Введите второе слово:");
        string word2 = Console.ReadLine();

        // Проверка, состоят ли слова из одних и тех же букв с учетом повторений и без учета регистра
        bool result = AreAnagrams(word1, word2);

        if (result)
        {
            Console.WriteLine("Слова состоят из одних и тех же букв.");
        }
        else
        {
            Console.WriteLine("Слова не состоят из одних и тех же букв.");
        }

        // Ожидание нажатия клавиши перед закрытием окна
        Console.WriteLine("Нажмите любую клавишу для выхода...");
        Console.ReadKey();
    }

    static bool AreAnagrams(string word1, string word2)
    {
        // Приводим слова к нижнему регистру
        word1 = word1.ToLower();
        word2 = word2.ToLower();

        // Сортируем символы в обоих словах
        char[] sortedWord1 = word1.OrderBy(c => c).ToArray();
        char[] sortedWord2 = word2.OrderBy(c => c).ToArray();

        // Сравниваем отсортированные массивы символов
        return sortedWord1.SequenceEqual(sortedWord2);
    }
}
