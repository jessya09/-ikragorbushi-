let currentValue = '0';
let operator = null;
let previousValue = null;

const display = document.getElementById('display');

function updateDisplay() {
    display.textContent = currentValue;
}

function clearDisplay() {
    currentValue = '0';
    operator = null;
    previousValue = null;
    updateDisplay();
}

function clearEntry() {
    currentValue = '0';
    updateDisplay();
}

function backspace() {
    currentValue = currentValue.length > 1 ? currentValue.slice(0, -1) : '0';
    updateDisplay();
}

function appendNumber(number) {
    if (currentValue === '0') {
        currentValue = number.toString();
    } else {
        currentValue += number.toString();
    }
    updateDisplay();
}

function appendDecimal() {
    if (!currentValue.includes('.')) {
        currentValue += '.';
        updateDisplay();
    }
}

function changeSign() {
    currentValue = (parseFloat(currentValue) * -1).toString();
    updateDisplay();
}

function operate(op) {
    if (operator !== null) {
        calculate();
    }
    operator = op;
    previousValue = currentValue;
    currentValue = '0';
}

function calculate() {
    const prev = parseFloat(previousValue);
    const curr = parseFloat(currentValue);
    if (isNaN(prev) || isNaN(curr)) return;
    switch (operator) {
        case '+':
            currentValue = (prev + curr).toString();
            break;
        case '-':
            currentValue = (prev - curr).toString();
            break;
        case '*':
            currentValue = (prev * curr).toString();
            break;
        case '/':
            currentValue = (prev / curr).toString();
            break;
        default:
            return;
    }
    operator = null;
    previousValue = null;
    updateDisplay();
}

function inverse() {
    currentValue = (1 / parseFloat(currentValue)).toString();
    updateDisplay();
}

function sqrt() {
    currentValue = Math.sqrt(parseFloat(currentValue)).toString();
    updateDisplay();
}

function percent() {
    currentValue = (parseFloat(currentValue) / 100).toString();
    updateDisplay();
}