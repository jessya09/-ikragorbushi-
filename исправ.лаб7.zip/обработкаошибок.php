// ... existing session and require code ...

try {
    $pdo->beginTransaction();
    
    // Добавляем проверку на корректность ID
    if ($room_id <= 0) {
        throw new Exception('Недопустимый ID комнаты');
    }
    
    // Проверяем существование комнаты
    $stmt = $pdo->prepare("SELECT id FROM rooms WHERE id = ?");
    if (!$stmt->execute([$room_id])) {
        throw new PDOException('Ошибка при проверке комнаты');
    }
    if (!$stmt->fetch()) {
        throw new Exception('Комната не найдена');
    }

    // Проверяем наличие активных бронирований
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE room_id = ? AND status != 'cancelled'");
    if (!$stmt->execute([$room_id])) {
        throw new PDOException('Ошибка при проверке бронирований');
    }
    $hasBookings = $stmt->fetchColumn() > 0;
    
    if (!$hasBookings) {
        // Удаление комнаты
        $stmt = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
        if (!$stmt->execute([$room_id])) {
            throw new PDOException('Ошибка при удалении комнаты');
        }
        
        // ... existing audit log and commit code ...
    }
    
} catch(PDOException $e) {
    $pdo->rollBack();
    writeAuditLog('room_delete_error', 'Ошибка базы данных: ' . $e->getMessage(), $_SESSION['user_id']);
    header('Location: dashboard.php?error=' . urlencode('Произошла ошибка при работе с базой данных'));
    exit();
} catch(Exception $e) {
    $pdo->rollBack();
    writeAuditLog('room_delete_error', $e->getMessage(), $_SESSION['user_id']);
    header('Location: dashboard.php?error=' . urlencode($e->getMessage()));
    exit();
}

// ... existing code ...